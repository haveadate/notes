// 引入样式
import './style/index.less';
console.log('hello, typescript.');
